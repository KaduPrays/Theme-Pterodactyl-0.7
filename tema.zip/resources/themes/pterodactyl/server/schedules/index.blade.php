{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.master')

@section('title')
    @lang('server.schedule.header')
@endsection

@section('content-header')
    <h1>@lang('server.schedule.header')<small>@lang('server.schedule.header_sub')</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('index') }}">@lang('strings.home')</a></li>
        <li><a href="{{ route('server.index', $server->uuidShort) }}">{{ $server->name }}</a></li>
        <li class="active">@lang('navigation.server.schedules')</li>
    </ol>
@endsection

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ $server->name }} - StabilityHost</title>
    <link rel="icon" type="image/x-icon" href="/images/stabilityicon.png">
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="/assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.min.css" integrity="sha256-2bAj1LMT7CXUYUwuEnqqooPb1W0Sw0uKMsqNH0HwMa4=" crossorigin="anonymous" />
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <script src="https://kit.fontawesome.com/4cfd508d4f.js" crossorigin="anonymous"></script>
</head>
<body class="dashboard">
    <header>
        <div class="dashboard-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 pt-2">
                    <a href="/" class="text-white logo" style="text-decoration: none;">
                        <h2 class="text-white text-left rm-logo"><img src="/images/kaduzyn.png" width="200"></h2>
                        </a>
                    </div>
                    <div class="col-md-8">
                        <div class="float-right">
                            <p class="text-white profile">
                                <span>
                                <i class="fas fa-address-card"></i> {{Auth::user()->name_first}} {{Auth::user()->name_last}}<br>
                                    <small>Bem-vindo de volta!</small>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                <nav class="navbar navbar-expand-lg dashboard-menu text-center">
            <div class="container">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.index', $server->uuidShort) }}"">Console do servidor</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.files.index', $server->uuidShort) }}">
                                <span>@lang('Gerenciador de arquivos')</span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.settings.sftp', $server->uuidShort) }}">
                                <span>@lang('SFTP')</span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.subusers', $server->uuidShort)}}">Sub-Usuários</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.databases.index', $server->uuidShort)}}">Banco de dados</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="{{ route('server.settings.startup', $server->uuidShort) }}">Configurações</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            @if(Auth::user()->root_admin)
                                <li>
                                    <li><a class="nav-link text-danger" href="{{ route('admin.index') }}" data-toggle="tooltip" data-placement="bottom" title="@lang('strings.admin_cp')">ADMIN</a></li>
                                </li>
                            @endif
                            <a class="nav-link text-danger" href="/auth/logout">
                                SAIR
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    <nav class="navbar navbar-expand-lg dashboard-menu text-center">
            <div class="container">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.settings.startup', $server->uuidShort) }}"">Inicialização</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.settings.name', $server->uuidShort) }}">
                                <span>@lang('Nome do servidor')</span>
                            </a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="{{ route('server.schedules', $server->uuidShort)}}">
                                <span>@lang('Tarefas agendadas')</span>
                            </a>
                        </li>
                </div>
    </header>
    <main class="content">
    <div class="container">
@section('content')
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">@lang('server.schedule.current')</h3>
                <div class="box-tools">
                    <a href="{{ route('server.schedules.new', $server->uuidShort) }}"><button class="btn btn-primary btn-sm">Criar tarefa</button></a>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table ">
                    <tbody>
                        <tr>
                            <th>@lang('strings.name')</th>
                            <th class="text-center">@lang('strings.queued')</th>
                            <th class="text-center">@lang('strings.tasks')</th>
                            <th>@lang('strings.last_run')</th>
                            <th>@lang('strings.next_run')</th>
                            <th></th>
                        </tr>
                        @foreach($schedules as $schedule)
                            <tr @if(! $schedule->is_active)class="muted muted-hover"@endif>
                                <td class="middle">
                                    @can('edit-schedule', $server)
                                        <a href="{{ route('server.schedules.view', ['server' => $server->uuidShort, '$schedule' => $schedule->hashid]) }}">
                                            {{ $schedule->name ?? trans('server.schedule.unnamed') }}
                                        </a>
                                    @else
                                        {{ $schedule->name ?? trans('server.schedule.unnamed') }}
                                    @endcan
                                </td>
                                <td class="middle text-center">
                                    @if ($schedule->is_processing)
                                        <span class="label label-success">@lang('strings.yes')</span>
                                    @else
                                        <span class="label label-default">@lang('strings.no')</span>
                                    @endif
                                </td>
                                <td class="middle text-center"><span class="label label-primary">{{ $schedule->tasks_count }}</span></td>
                                <td class="middle">
                                @if($schedule->last_run_at)
                                    {{ Carbon::parse($schedule->last_run_at)->toDayDateTimeString() }}<br /><span class="text-muted small">({{ Carbon::parse($schedule->last_run_at)->diffForHumans() }})</span>
                                @else
                                    <em class="text-muted">@lang('strings.not_run_yet')</em>
                                @endif
                                </td>
                                <td class="middle">
                                    @if($schedule->is_active)
                                        {{ Carbon::parse($schedule->next_run_at)->toDayDateTimeString() }}<br /><span class="text-muted small">({{ Carbon::parse($schedule->next_run_at)->diffForHumans() }})</span>
                                    @else
                                        <em>n/a</em>
                                    @endif
                                </td>
                                <td class="middle">
                                    @can('delete-schedule', $server)
                                        <a class="btn btn-xs btn-danger" href="#" data-action="delete-schedule" data-schedule-id="{{ $schedule->hashid }}" data-toggle="tooltip" data-placement="top" title="@lang('strings.delete')"><i class="fa fa-fw fa-trash-o"></i></a>
                                    @endcan
                                    @can('toggle-schedule', $server)
                                        <a class="btn btn-xs btn-default" href="#" data-action="toggle-schedule" data-active="{{ $schedule->active }}" data-schedule-id="{{ $schedule->hashid }}" data-toggle="tooltip" data-placement="top" title="@lang('server.schedule.toggle')"><i class="fa fa-fw fa-eye-slash"></i></a>
                                        <a class="btn btn-xs btn-default" href="#" data-action="trigger-schedule" data-schedule-id="{{ $schedule->hashid }}" data-toggle="tooltip" data-placement="top" title="@lang('server.schedule.run_now')"><i class="fa fa-fw fa-refresh"></i></a>
                                    @endcan
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('js/frontend/server.socket.js') !!}
    {!! Theme::js('js/frontend/tasks/management-actions.js') !!}
@endsection
