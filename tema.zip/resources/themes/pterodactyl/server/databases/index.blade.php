@extends('layouts.master')

@section('title')
    {{ trans('server.index.title', [ 'name' => $server->name]) }}
@endsection

@section('scripts')
    @parent
    {!! Theme::css('css/terminal.css') !!}
@endsection

@section('content-header')
    <h1>@lang('server.index.header')<small>@lang('server.index.header_sub')</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('index') }}">@lang('strings.servers')</a></li>
        <li class="active">{{ $server->name }}</li>
    </ol>
@endsection

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ $server->name }} - StabilityHost</title>
    <link rel="icon" type="image/x-icon" href="/images/stabilityicon.png">
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="/assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.min.css" integrity="sha256-2bAj1LMT7CXUYUwuEnqqooPb1W0Sw0uKMsqNH0HwMa4=" crossorigin="anonymous" />
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <script src="https://kit.fontawesome.com/4cfd508d4f.js" crossorigin="anonymous"></script>
</head>
<body class="dashboard">
    <header>
        <div class="dashboard-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 pt-2">
                    <a href="/" class="text-white logo" style="text-decoration: none;">
                        <h2 class="text-white text-left rm-logo"><img src="/images/kaduzyn.png" width="200"></h2>
                        </a>
                    </div>
                    <div class="col-md-8">
                        <div class="float-right">
                            <p class="text-white profile">
                                <span>
                                <i class="fas fa-address-card"></i> {{Auth::user()->name_first}} {{Auth::user()->name_last}}<br>
                                    <small>Bem-vindo de volta!</small>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                <nav class="navbar navbar-expand-lg dashboard-menu text-center">
            <div class="container">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.index', $server->uuidShort) }}">Console do servidor</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.files.index', $server->uuidShort) }}">
                                <span>@lang('Gerenciador de arquivos')</span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.settings.sftp', $server->uuidShort) }}">
                                <span>@lang('SFTP')</span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.subusers', $server->uuidShort)}}">Sub-Usuários</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="{{ route('server.databases.index', $server->uuidShort)}}">Banco de dados</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('server.settings.startup', $server->uuidShort) }}">Configurações</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            @if(Auth::user()->root_admin)
                                <li>
                                    <li><a class="nav-link text-danger" href="{{ route('admin.index') }}" data-toggle="tooltip" data-placement="bottom" title="@lang('strings.admin_cp')">ADMIN</a></li>
                                </li>
                            @endif
                            <a class="nav-link text-danger" href="/auth/logout">
                                SAIR
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main class="content">
    <div class="container">

@section('content-header')
    <h1>@lang('server.config.database.header')<small>@lang('server.config.database.header_sub')</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('index') }}">@lang('strings.home')</a></li>
        <li><a href="{{ route('server.index', $server->uuidShort) }}">{{ $server->name }}</a></li>
        <li>@lang('navigation.server.configuration')</li>
        <li class="active">@lang('navigation.server.databases')</li>
    </ol>
@endsection

@section('content')
<div class="row">
    <div class="{{ $allowCreation && Gate::allows('create-database', $server) ? 'col-xs-12 col-sm-8' : 'col-xs-12' }}">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Database criadas</h3>
            </div>
            @if(count($databases) > 0)
                <div class="box-body table-responsive no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>@lang('Database')</th>
                                <th>@lang('Usuário')</th>
                                <th>@lang('Senha')</th>
                                <th>@lang('Host MySQL')</th>
                                @can('reset-db-password', $server)<td></td>@endcan
                            </tr>
                            @foreach($databases as $database)
                                <tr>
                                    <td class="middle">{{ $database->database }}</td>
                                    <td class="middle">{{ $database->username }}</td>
                                    <td class="middle">
                                        <code class="toggle-display" style="cursor:pointer" data-toggle="tooltip" data-placement="right" title="Clique para revelar">
                                            <i class="fa fa-key"></i> &bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;</i>
                                        </code>
                                        <code class="hidden" data-attr="set-password">
                                            {{ Crypt::decrypt($database->password) }}
                                        </code>
                                    </td>
                                    <td class="middle"><code>{{ $database->host->host }}:{{ $database->host->port }}</code></td>
                                    @if(Gate::allows('reset-db-password', $server) || Gate::allows('delete-database', $server))
                                        <td>
                                            @can('delete-database', $server)
                                                <button class="btn btn-xs btn-danger pull-right" data-action="delete-database" data-id="{{ $database->id }}">
                                                    <i class="fa fa-fw fa-trash-o"></i>
                                                </button>
                                            @endcan
                                            @can('reset-db-password', $server)
                                                <button class="btn btn-primary " style="margin-right:10px;" data-action="reset-password" data-id="{{ $database->id }}">
                                                    <i class="fa fa-refresh"></i>
                                                </button>
                                            @endcan
                                        </td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @else
                <div class="box-body">
                    <div class="alert alert-danger no-margin-bottom">
                        Não há bancos de dados listados para este servidor.
                    </div>
                </div>
            @endif
        </div>
    </div>
    @if($allowCreation && Gate::allows('create-database', $server))
        <div class="col-xs-12 col-sm-4">
            <div class="box box">
                <div class="box-header with-border text-center">
                    <h3 class="box-title"> <i class="fa fa-fw fa-database"></i> BANCO DE DADOS <i class="fa fa-fw fa-database"></i></h3>
                </div>
                @if($overLimit)
                    <div class="box-body">
                        <div class="alert alert-danger no-margin">
                            Você está usando atualmente <strong>{{ count($databases) }}</strong> do seu <strong>{{ $server->database_limit ?? '∞' }}</strong> bancos de dados permitidos.
                        </div>
                    </div>
                @else
                    <form action="{{ route('server.databases.new', $server->uuidShort) }}" method="POST">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="pDatabaseName" class="control-label">Database</label>
                                <div class="input-group">
                                    <span class="input-group-addon"></span>
                                    <input id="pDatabaseName" type="text" name="database" class="form-control" placeholder="database" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="pRemote" class="control-label">Conexões IP</label>
                                <input id="pRemote" type="text" name="remote" class="form-control" value="%" />
                            </div>
                        </div>
                        <div class="box-footer text-center">
                            {!! csrf_field() !!}
                            <input type="submit" class="btn btn-sm btn-success pull-right" value="Criar database" />
                        </div>
                    </form>
                @endif
            </div>
        </div>
    @endif
</div>
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('js/frontend/server.socket.js') !!}
    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        });
        $('.toggle-display').on('click', function () {
            $(this).parent().find('code[data-attr="set-password"]').removeClass('hidden');
            $(this).hide();
        });
        @can('reset-db-password', $server)
            $('[data-action="reset-password"]').click(function (e) {
                e.preventDefault();
                var block = $(this);
                $(this).addClass('disabled').find('i').addClass('fa-spin');
                $.ajax({
                    type: 'PATCH',
                    url: Router.route('server.databases.password', { server: Pterodactyl.server.uuidShort }),
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content'),
                    },
                    data: {
                        database: $(this).data('id')
                    }
                }).done(function (data) {
                    block.parent().parent().find('[data-attr="set-password"]').html(data.password);
                }).fail(function(jqXHR) {
                    console.error(jqXHR);
                    var error = 'An error occurred while trying to process this request.';
                    if (typeof jqXHR.responseJSON !== 'undefined' && typeof jqXHR.responseJSON.error !== 'undefined') {
                        error = jqXHR.responseJSON.error;
                    }
                    swal({
                        type: 'error',
                        title: 'Whoops!',
                        text: error
                    });
                }).always(function () {
                    block.removeClass('disabled').find('i').removeClass('fa-spin');
                });
            });
        @endcan
        @can('delete-database', $server)
            $('[data-action="delete-database"]').click(function (event) {
                event.preventDefault();
                var self = $(this);
                swal({
                    title: '',
                    type: 'warning',
                    text: 'Tem certeza de que deseja excluir este banco de dados? Não há como voltar atrás, todos os dados serão removidos imediatamente.',
                    showCancelButton: true,
                    confirmButtonText: 'Deletar',
                    confirmButtonColor: '#d9534f',
                    closeOnConfirm: false,
                    showLoaderOnConfirm: true,
                }, function () {
                    $.ajax({
                        method: 'DELETE',
                        url: Router.route('server.databases.delete', { server: '{{ $server->uuidShort }}', database: self.data('id') }),
                        headers: { 'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content') },
                    }).done(function () {
                        self.parent().parent().slideUp();
                        swal.close();
                    }).fail(function (jqXHR) {
                        console.error(jqXHR);
                        swal({
                            type: 'error',
                            title: 'Whoops!',
                            text: (typeof jqXHR.responseJSON.error !== 'undefined') ? jqXHR.responseJSON.error : 'An error occurred while processing this request.'
                        });
                    });
                });
            });
        @endcan
    </script>
@endsection
