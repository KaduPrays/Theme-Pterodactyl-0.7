{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.auth')

@section('title')
     Acessar conta
@endsection

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Área de Login - StabilityHost</title>
    <link rel="icon" type="image/x-icon" href="/images/stabilityicon.png">
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="/assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.min.css" integrity="sha256-2bAj1LMT7CXUYUwuEnqqooPb1W0Sw0uKMsqNH0HwMa4=" crossorigin="anonymous" />
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
</head>

@section('content')
<div class="row">
<div class="login-card px-5">
  <div class="px-5">
    <br>
    <br>
                        @if (count($errors) > 0)
            <div class="alert alert-danger text-center">
                Não foi possível localizar essa conta!
            </div>
        @endif
    <br>
    <h1 class="font-weight-bold text-center title mt-3">STABILITY HOST</h1>
    <div class="divider w-25"></div>
    <p class="mt-2 text-muted mb-5 text-center">Entre na sua conta com seu e-mail e senha</p>
    <span class="text-danger" id="alert" style="display: none;"></span>
    <label class="font-weight-bold text-muted">E-mail</label>
        <form id="loginForm" action="{{ route('auth.login') }}" method="POST">
            <div class="form-group has-feedback">
                <div class="pterodactyl-login-input">
                    <input type="text" name="user" class="form-control form-control-lg" value="{{ old('user') }}" >
                    <span class="fa fa-envelope form-control-feedback fa-lg"></span>
                </div>
            </div>
            <div class="form-group has-feedback">
                <div class="pterodactyl-login-input">
                  <label class="font-weight-bold text-muted">Senha</label>
                    <input type="password" name="password" class="form-control form-control-lg" >
                    <span class="fa fa-lock form-control-feedback fa-lg"></span>
                </div>
            </div>
                <div class="col-xs-offset-4 col-xs-4">
                    {!! csrf_field() !!}
                    <button type="submit" class="btn btn-secondary btn-block btn-rounded mt-3 btn btn-block g-recaptcha pterodactyl-login-button--main" @if(config('recaptcha.enabled')) data-sitekey="{{ config('recaptcha.website_key') }}" data-callback='onSubmit' @endif>@lang('Entrar na conta')</button>
                </div>
                            <div class="row">
                <div class="col-xs-4">
                    <a href="{{ route('auth.password') }}"><button type="button" class="btn pterodactyl-login-button--left"><i class="fa fa-life-ring"></i></button></a>
                </div>
            </div>
        </form>
                    </div>
<a class="btn btn-link btn-block text-muted" href="/auth/password">Esqueceu sua senha? Clique aqui</a>
</div>
    </div>
</div>
@endsection

@section('scripts')
    @parent
    @if(config('recaptcha.enabled'))
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
        <script>
        function onSubmit(token) {
            document.getElementById("loginForm").submit();
        }
        </script>
     @endif
@endsection
