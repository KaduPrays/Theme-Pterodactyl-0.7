<?php

return [
    'next' => 'Järgmine &raquo;',
    'previous' => '&laquo; Eelmine',
    'sidebar' => [
        'account_controls' => 'Kasutaja seaded',
        'account_security' => 'Konto turvalisus',
        'account_settings' => 'Konto seaded',
        'files' => 'Failihaldur',
        'manage' => 'Halda serverit',
        'overview' => 'Serveri ülevaade',
        'servers' => 'Teie serverid',
        'server_controls' => 'Serveri seaded',
        'subusers' => 'Halda alamkasutajaid',
    ],
];
