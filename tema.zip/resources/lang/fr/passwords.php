<?php

return [
    'password' => 'Mot de passe',
    'reset' => 'Votre mot de passe à été réinitialisé! ',
    'sent' => 'Nous vous avons envoyé par e-mail votre lien de réinitialisation de mot de passe!',
];
