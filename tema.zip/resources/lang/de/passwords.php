<?php

return [
    'password' => 'Passwort',
    'reset' => 'Dein Passwort wurde zurückgesetzt!',
    'sent' => 'Ein Link zum zurücksetzen des Passworts wurde per E-Mail gesendet!',
    'token' => 'Der Token war ungültig',
    'user' => 'Es gibt keinen Benutzer mit dieser E-Mail.',
];
