
<?php
return [
    'next' => 'Nächste &raquo;',
    'previous' => '&laquo; Vorherige',
    'sidebar' => [
        'account_controls' => 'Kontosteuerung',
        'account_security' => 'Kontosicherheit',
        'account_settings' => 'Kontoeinstellungen',
        'files' => 'Dateimanager',
        'manage' => 'Server verwalten',
        'overview' => 'Server Übersicht',
        'servers' => 'Deine Server',
        'subusers' => 'Subuser verwalten',
    ],
];
